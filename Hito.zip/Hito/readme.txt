Leak by Mezy#1337 - fuck all this botnet shit, you kids need to calm the fuck down.

You guys are going to get yourself into trouble for dumb fucking reasons, and it's literally so dumb the amount of people being arrested for ddosing a site for 3 minutes to
"flex" on niggas, if you're still ddosing (which I assume you are by downloading this source) I promise you that it's going to catch up to you, and you're going to regret it.

Hito made by Light The Leafeon#0001 LEAKED!

RIP to my brother Piff, you are a fucking idiot when you're drunk.. but I love you bro ;) stay safe.
https://www.bbc.com/news/uk-england-lancashire-47708237
https://www.liverpoolecho.co.uk/news/liverpool-news/teenager-accused-cyber-attacks-two-16040831
https://www.warringtonguardian.co.uk/news/15675096.extremely-immature-teen-locked-up-following-bomb-hoax-days-after-manchester-arena-terror-attack/
https://www.cheshire-live.co.uk/news/chester-cheshire-news/man-charged-over-alleged-cyberattack-16041213